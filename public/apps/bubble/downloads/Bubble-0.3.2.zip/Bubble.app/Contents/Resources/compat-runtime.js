/* Bubble's PopClip extension compatibility runtime.
 * Everything here runs inside JavaScriptCore, never Node.
 */
(function (global) {
  "use strict";

  global.global = global;
  global.globalThis = global;
  global.process = global.process || {
    env: {},
    platform: "darwin",
    versions: { node: "20.0.0" },
    cwd: function () { return "/"; }
  };
  function bubbleLog() {
    var parts = [];
    for (var i = 0; i < arguments.length; i++) {
      var value = arguments[i];
      try { parts.push(typeof value === "object" ? JSON.stringify(value) : String(value)); }
      catch (error) { parts.push(String(value)); }
    }
    var message = parts.join(" ");
    try { __bubbleLog(message); } catch (error) {}
  }
  global.print = bubbleLog;
  global.console = {
    log: bubbleLog,
    info: bubbleLog,
    warn: bubbleLog,
    error: bubbleLog,
    debug: bubbleLog
  };

  if (typeof global.__bubbleCaptured === "undefined") {
    global.__bubbleCaptured = [];
  }
  if (typeof global.defineExtension !== "function") {
    global.defineExtension = function (object) {
      global.__bubbleCaptured.push(object);
      return object;
    };
  }
  if (typeof global.define !== "function") {
    global.define = function (value) {
      var result = typeof value === "function" ? value() : value;
      global.__bubbleLastDefine = result;
      global.__bubbleCaptured.push(result);
      return result;
    };
  }
  global.__bubbleLastDefine = undefined;

  /* ---------- URL ---------- */
  function encodeQueryValue(value) {
    return encodeURIComponent(String(value));
  }

  function URLSearchParams(init) {
    this._pairs = [];
    if (typeof init === "string") {
      var self = this;
      init.replace(/^\?/, "").split("&").forEach(function (pair) {
        if (!pair) return;
        var index = pair.indexOf("=");
        var key = index < 0 ? pair : pair.slice(0, index);
        var value = index < 0 ? "" : pair.slice(index + 1);
        self._pairs.push([
          decodeURIComponent(key.replace(/\+/g, " ")),
          decodeURIComponent(value.replace(/\+/g, " "))
        ]);
      });
    } else if (init && typeof init === "object") {
      if (typeof init.forEach === "function" && !Array.isArray(init)) {
        var copy = this;
        init.forEach(function (value, key) { copy._pairs.push([String(key), String(value)]); });
      } else {
        for (var key in init) {
          if (Object.prototype.hasOwnProperty.call(init, key)) {
            this._pairs.push([String(key), String(init[key])]);
          }
        }
      }
    }
  }
  URLSearchParams.prototype.append = function (key, value) {
    this._pairs.push([String(key), String(value)]);
  };
  URLSearchParams.prototype.delete = function (key) {
    this._pairs = this._pairs.filter(function (pair) { return pair[0] !== String(key); });
  };
  URLSearchParams.prototype.get = function (key) {
    for (var i = 0; i < this._pairs.length; i++) {
      if (this._pairs[i][0] === String(key)) return this._pairs[i][1];
    }
    return null;
  };
  URLSearchParams.prototype.getAll = function (key) {
    return this._pairs.filter(function (pair) { return pair[0] === String(key); })
      .map(function (pair) { return pair[1]; });
  };
  URLSearchParams.prototype.has = function (key) {
    return this._pairs.some(function (pair) { return pair[0] === String(key); });
  };
  URLSearchParams.prototype.set = function (key, value) {
    this.delete(key);
    this.append(key, value);
  };
  URLSearchParams.prototype.forEach = function (callback) {
    this._pairs.forEach(function (pair) { callback(pair[1], pair[0], this); }, this);
  };
  URLSearchParams.prototype.toString = function () {
    return this._pairs.map(function (pair) {
      return encodeQueryValue(pair[0]) + "=" + encodeQueryValue(pair[1]);
    }).join("&");
  };

  function URL(input, base) {
    var raw = String(input);
    if (base && !/^[a-z][a-z0-9+.-]*:/i.test(raw)) {
      try {
        var baseURL = new URL(String(base));
        raw = baseURL.protocol + "//" + baseURL.host + "/" + raw.replace(/^\//, "");
      } catch (error) {}
    }
    var match = raw.match(/^([a-z][a-z0-9+.-]*:)(?:\/\/([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/i);
    if (!match) throw new TypeError("Invalid URL: " + raw);
    this.protocol = match[1].toLowerCase();
    this.host = match[2] || "";
    this.hostname = this.host.split(":")[0];
    this.pathname = match[3] || "";
    this._search = match[4] || "";
    this._hash = match[5] ? "#" + match[5] : "";
    this._searchParams = new URLSearchParams(this._search);
    var self = this;
    this._searchParams.toString = function () {
      var value = URLSearchParams.prototype.toString.call(self._searchParams);
      self._search = value;
      return value;
    };
  }
  Object.defineProperty(URL.prototype, "searchParams", {
    get: function () { return this._searchParams; }
  });
  Object.defineProperty(URL.prototype, "search", {
    get: function () {
      var value = this._searchParams.toString();
      return value ? "?" + value : "";
    }
  });
  Object.defineProperty(URL.prototype, "hash", {
    get: function () { return this._hash; },
    set: function (value) { this._hash = value ? (String(value)[0] === "#" ? String(value) : "#" + value) : ""; }
  });
  Object.defineProperty(URL.prototype, "href", {
    get: function () { return this.toString(); },
    set: function (value) {
      var replacement = new URL(String(value));
      this.protocol = replacement.protocol;
      this.host = replacement.host;
      this.hostname = replacement.hostname;
      this.pathname = replacement.pathname;
      this._search = replacement._search;
      this._hash = replacement._hash;
      this._searchParams = replacement._searchParams;
    }
  });
  URL.prototype.toString = function () {
    var query = this._searchParams.toString();
    var authority = this.host ? "//" + this.host : "";
    return this.protocol + authority + this.pathname + (query ? "?" + query : "") + this._hash;
  };
  URL.prototype.toJSON = function () { return this.toString(); };
  global.URL = URL;
  global.URLSearchParams = URLSearchParams;

  function RichString(source, options) {
    var format = (options && options.format) ? String(options.format) : "rtf";
    var json = __bubbleRichString(String(source), format);
    var result = {};
    try { result = json ? JSON.parse(json) : {}; } catch (error) {}
    this.rtf = result.rtf || "";
    this.html = result.html || "";
  }
  global.RichString = RichString;

  global.atob = function (value) { return __bubbleAtob(String(value)); };
  global.btoa = function (value) { return __bubbleBtoa(String(value)); };
  function utf8ToBytes(value) {
    var text = String(value);
    var bytes = [];
    for (var i = 0; i < text.length; i++) {
      var code = text.charCodeAt(i);
      if (code < 0x80) {
        bytes.push(code);
      } else if (code < 0x800) {
        bytes.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f));
      } else if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length) {
        var next = text.charCodeAt(i + 1);
        var point = 0x10000 + ((code - 0xd800) << 10) + (next - 0xdc00);
        i++;
        bytes.push(
          0xf0 | (point >> 18),
          0x80 | ((point >> 12) & 0x3f),
          0x80 | ((point >> 6) & 0x3f),
          0x80 | (point & 0x3f)
        );
      } else {
        bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToString(bytes) {
    var text = "";
    for (var i = 0; i < bytes.length; i++) text += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(text)); } catch (error) { return text; }
  }
  var BASE64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  function bytesToBase64(bytes) {
    var output = "";
    for (var i = 0; i < bytes.length; i += 3) {
      var a = bytes[i];
      var b = i + 1 < bytes.length ? bytes[i + 1] : 0;
      var c = i + 2 < bytes.length ? bytes[i + 2] : 0;
      output += BASE64_ALPHABET[a >> 2];
      output += BASE64_ALPHABET[((a & 3) << 4) | (b >> 4)];
      output += i + 1 < bytes.length ? BASE64_ALPHABET[((b & 15) << 2) | (c >> 6)] : "=";
      output += i + 2 < bytes.length ? BASE64_ALPHABET[c & 63] : "=";
    }
    return output;
  }
  function base64ToBytes(value) {
    var text = String(value).replace(/[^A-Za-z0-9+\/_\-=]/g, "")
      .replace(/-/g, "+").replace(/_/g, "/");
    var output = [];
    var buffer = 0, bits = 0;
    for (var i = 0; i < text.length; i++) {
      var character = text[i];
      if (character === "=") break;
      var index = BASE64_ALPHABET.indexOf(character);
      if (index < 0) continue;
      buffer = (buffer << 6) | index;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        output.push((buffer >> bits) & 0xff);
      }
    }
    return new Uint8Array(output);
  }
  function toBytes(value) {
    if (value instanceof Uint8Array) return value;
    if (value && value._bytes instanceof Uint8Array) return value._bytes;
    if (Array.isArray(value)) return new Uint8Array(value);
    return utf8ToBytes(value);
  }
  function BufferValue(bytes) { this._bytes = bytes; this.length = bytes.length; }
  BufferValue.prototype.toString = function (encoding) {
    if (String(encoding || "utf8").toLowerCase() === "base64") return bytesToBase64(this._bytes);
    return bytesToString(this._bytes);
  };
  global.Buffer = {
    from: function (value) { return new BufferValue(toBytes(value)); },
    isBuffer: function (value) { return value instanceof BufferValue; }
  };

  /* ---------- timers ---------- */
  global.__bubbleTimerCallbacks = {};
  global.__bubbleNextTimer = 1;
  global.setTimeout = function (callback, delay) {
    var id = global.__bubbleNextTimer++;
    global.__bubbleTimerCallbacks[id] = callback;
    __bubbleSetTimeout(id, Number(delay) || 0);
    return id;
  };
  global.clearTimeout = function (id) {
    delete global.__bubbleTimerCallbacks[id];
    __bubbleClearTimeout(id);
  };
  global.setInterval = function (callback, delay) { return global.setTimeout(callback, delay); };
  global.clearInterval = global.clearTimeout;
  global.__bubbleFireTimer = function (id) {
    var callback = global.__bubbleTimerCallbacks[id];
    delete global.__bubbleTimerCallbacks[id];
    if (typeof callback === "function") callback();
  };

  /* ---------- util ---------- */
  var preferredLanguage = "en";
  try {
    if (typeof __bubblePreferredLanguage === "string") preferredLanguage = __bubblePreferredLanguage;
  } catch (error) {}

  function localized(value) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      if (Object.prototype.hasOwnProperty.call(value, preferredLanguage)) return value[preferredLanguage];
      if (preferredLanguage.indexOf("zh") === 0 && value["zh-Hans"]) return value["zh-Hans"];
      if (value["en"]) return value["en"];
      var keys = Object.keys(value);
      return keys.length ? value[keys[0]] : "";
    }
    return value;
  }

  function replaceRanges(text, ranges, replacements) {
    function* between() {
      var position = 0;
      for (var i = 0; i < ranges.length; i++) {
        yield text.substring(position, ranges[i].location);
        position = ranges[i].location + ranges[i].length;
      }
      yield text.substring(position);
    }
    var sections = between();
    var result = sections.next().value || "";
    for (var i = 0; i < replacements.length; i++) {
      result += replacements[i] + (sections.next().value || "");
    }
    return result;
  }

  async function replaceRangesAsync(text, ranges, replacements) {
    function* between() {
      var position = 0;
      for (var i = 0; i < ranges.length; i++) {
        yield text.substring(position, ranges[i].location);
        position = ranges[i].location + ranges[i].length;
      }
      yield text.substring(position);
    }
    var sections = between();
    var result = sections.next().value || "";
    for await (var replacement of replacements) {
      result += replacement + (sections.next().value || "");
    }
    return result;
  }

  async function* concurrentTransform(items, transform) {
    var list = Array.from(items);
    var unique = Array.from(new Set(list));
    var table = new Map();
    await Promise.all(unique.map(async function (item) {
      table.set(item, await transform(item));
    }));
    for (var i = 0; i < list.length; i++) yield table.get(list[i]);
  }

  function transformLines(text, transform) {
    return text.replace(/^(\s*)(.*?)(\s*)$/gm, function (match, before, middle, after) {
      return before + transform(middle) + (after || "");
    });
  }

  function replaceSpaces(text, character) {
    if (/[^\S\r\n]/.test(text)) {
      return text.replace(/([^\S\r\n]+)/g, character);
    }
    var regex = new RegExp("[" + character + "]+", "g");
    return text.replace(regex, " ");
  }

  function simpleCase(value, mode) {
    var text = String(value);
    var words = text
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/[_\-\s]+/g, " ")
      .trim()
      .split(/\s+/)
      .filter(Boolean);
    if (mode === "camel") {
      return words.map(function (word, index) {
        var lower = word.toLowerCase();
        return index === 0 ? lower : lower.charAt(0).toUpperCase() + lower.slice(1);
      }).join("");
    }
    if (mode === "pascal") {
      return words.map(function (word) {
        var lower = word.toLowerCase();
        return lower.charAt(0).toUpperCase() + lower.slice(1);
      }).join("");
    }
    if (mode === "kebab") return words.map(function (word) { return word.toLowerCase(); }).join("-");
    if (mode === "snake") return words.map(function (word) { return word.toLowerCase(); }).join("_");
    return text;
  }

  global.util = {
    localize: localized,
    clarify: function (value) { return value; },
    buildQuery: function (object) {
      var params = new URLSearchParams();
      if (object) Object.keys(object).forEach(function (key) {
        var value = object[key];
        if (value !== undefined && value !== null) params.append(key, value);
      });
      return params.toString();
    },
    parseQuery: function (value) {
      var params = new URLSearchParams(String(value || ""));
      var object = {};
      params.forEach(function (v, k) { object[k] = v; });
      return object;
    },
    base64Encode: function (value, options) {
      var bytes = toBytes(value);
      var encoded = bytesToBase64(bytes);
      if (options && options.urlSafe) {
        encoded = encoded.replace(/\+/g, "-").replace(/\//g, "_");
      }
      if (options && options.trimmed) encoded = encoded.replace(/=+$/, "");
      return encoded;
    },
    base64Decode: function (value, options) {
      var bytes = base64ToBytes(value);
      if (options && options.bytes) return bytes;
      return bytesToString(bytes);
    },
    hmac: function (data, key, algorithm) {
      var encoded = __bubbleHmac(
        bytesToBase64(toBytes(data)),
        bytesToBase64(toBytes(key)),
        String(algorithm || "sha1").toLowerCase()
      );
      if (!encoded) throw new Error("Unsupported HMAC algorithm: " + algorithm);
      return base64ToBytes(encoded);
    },
    hash: function (data, algorithm) {
      var encoded = __bubbleHash(
        bytesToBase64(toBytes(data)),
        String(algorithm || "sha1").toLowerCase()
      );
      if (!encoded) throw new Error("Unsupported hash algorithm: " + algorithm);
      return base64ToBytes(encoded);
    },
    sleep: function (milliseconds) {
      __bubbleSleepSync(Number(milliseconds) || 0);
      return Promise.resolve();
    },
    localeInfo: function () {
      var parts = preferredLanguage.split("-");
      var region = parts[1] || "US";
      return {
        localeIdentifier: preferredLanguage.replace("-", "_"),
        regionCode: region,
        languageCode: parts[0] || "en",
        decimalSeparator: ".",
        groupingSeparator: ",",
        currencyCode: "USD",
        currencySymbol: "$",
        identifier: preferredLanguage,
        language: parts[0] || "en",
        region: region
      };
    },
    timeZoneInfo: (function () {
      var info = { identifier: "UTC", abbreviation: "UTC", secondsOffset: 0, daylightSaving: false };
      try {
        var json = __bubbleTimeZoneInfo();
        if (json) info = JSON.parse(json);
      } catch (error) {}
      return info;
    })(),
    randomUuid: function () {
      var hex = "0123456789abcdef";
      var out = "";
      for (var i = 0; i < 36; i++) {
        if (i === 8 || i === 13 || i === 18 || i === 23) out += "-";
        else if (i === 14) out += "4";
        else out += hex[Math.floor(Math.random() * 16)];
      }
      return out;
    },
    getRandomValues: function (array) {
      for (var i = 0; i < array.length; i++) array[i] = Math.floor(Math.random() * 256);
      return array;
    },
    htmlToMarkdown: function (value) { return String(value); },
    transformLines: transformLines,
    replaceSpaces: replaceSpaces,
    generator: concurrentTransform,
    replaceRanges: replaceRanges,
    case: {
      camelCase: function (v) { return simpleCase(v, "camel"); },
      pascalCase: function (v) { return simpleCase(v, "pascal"); },
      kebabCase: function (v) { return simpleCase(v, "kebab"); },
      snakeCase: function (v) { return simpleCase(v, "snake"); }
    }
  };

  global.__bubbleHelpers = {
    "replace-ranges": { replaceRanges: replaceRanges, replaceRangesAsync: replaceRangesAsync },
    "generator": { concurrentTransform: concurrentTransform },
    "transform-lines": { transformLines: transformLines },
    "replace-spaces": { replaceSpaces: replaceSpaces }
  };

  /* ---------- HTTP / axios / fetch ---------- */
  function axiosRequest(method, url, data, config) {
    config = config || {};
    var target = String(url);
    if (config.baseURL && !/^[a-z][a-z0-9+.-]*:\/\//i.test(target)) {
      target = String(config.baseURL).replace(/\/$/, "") + "/" + target.replace(/^\//, "");
    }
    var headers = Object.assign({}, config.headers || {});
    if (config.params) {
      var query = new URLSearchParams();
      Object.keys(config.params).forEach(function (key) {
        var value = config.params[key];
        if (value !== undefined && value !== null) query.append(key, value);
      });
      var serialized = query.toString();
      if (serialized) target += (target.indexOf("?") >= 0 ? "&" : "?") + serialized;
    }
    var body = null;
    if (data !== undefined && data !== null) {
      if (typeof data === "string") body = data;
      else {
        body = JSON.stringify(data);
        if (!headers["Content-Type"] && !headers["content-type"]) {
          headers["Content-Type"] = "application/json";
        }
      }
    }
    return new Promise(function (resolve, reject) {
      try {
        __bubbleHTTPStart(String(method || "GET").toUpperCase(), target, body, headers, resolve, reject);
      } catch (error) {
        reject(error);
      }
    }).then(function (response) {
      if (response.status >= 400) {
        var error = new Error("HTTP " + response.status);
        error.response = response;
        throw error;
      }
      return response;
    });
  }

  function axiosInstance(defaults) {
    function merge(config) {
      var merged = Object.assign({}, defaults, config || {});
      merged.headers = Object.assign({}, defaults.headers || {}, (config && config.headers) || {});
      return merged;
    }
    var instance = {
      defaults: defaults || {},
      interceptors: {
        request: { use: function () {} },
        response: { use: function () {} }
      },
      request: function (config) {
        var merged = merge(config);
        return axiosRequest(merged.method, merged.url, merged.data, merged);
      },
      get: function (url, config) { return axiosRequest("GET", url, null, merge(config)); },
      delete: function (url, config) { return axiosRequest("DELETE", url, null, merge(config)); },
      head: function (url, config) { return axiosRequest("HEAD", url, null, merge(config)); },
      post: function (url, data, config) { return axiosRequest("POST", url, data, merge(config)); },
      put: function (url, data, config) { return axiosRequest("PUT", url, data, merge(config)); },
      patch: function (url, data, config) { return axiosRequest("PATCH", url, data, merge(config)); }
    };
    instance.create = function (more) {
      return axiosInstance(Object.assign({}, defaults, more || {}, {
        headers: Object.assign({}, defaults.headers || {}, (more && more.headers) || {})
      }));
    };
    return instance;
  }

  global.axios = axiosInstance({});
  global.axios.isAxiosError = function (error) { return !!(error && error.response); };
  global.axios.CancelToken = { source: function () { return { token: {}, cancel: function () {} }; } };
  global.axios.all = function (promises) { return Promise.all(promises); };
  global.axios.spread = function (callback) { return function (values) { return callback.apply(null, values); }; };
  global["@popclip/axios"] = global.axios;

  global.fetch = function (input, init) {
    var options = init || {};
    return new Promise(function (resolve, reject) {
      var method = options.method || "GET";
      var body = options.body === undefined ? null : options.body;
      var headers = options.headers || {};
      __bubbleHTTPStart(method, String(input), body, headers, function (response) {
        resolve({
          ok: response.status >= 200 && response.status < 300,
          status: response.status,
          headers: response.headers,
          text: function () {
            return Promise.resolve(typeof response.data === "string" ? response.data : JSON.stringify(response.data));
          },
          json: function () {
            return Promise.resolve(typeof response.data === "string" ? JSON.parse(response.data) : response.data);
          }
        });
      }, reject);
    });
  };

  global.XMLHttpRequest = function () {
    this.open = function () {};
    this.send = function () {};
    this.setRequestHeader = function () {};
    this.readyState = 4;
    this.status = 200;
    this.responseText = "";
  };

  global.__bubbleModuleCache = {};
  global.require = function (name) {
    if (name === "axios" || name === "@popclip/axios") return global.axios;
    if (name === "case-anything") return global.util.case;
    if (name === "rot13-cipher") {
      return function (text) {
        return String(text).replace(/[a-zA-Z]/g, function (character) {
          var code = character.charCodeAt(0);
          if (code >= 65 && code <= 90) return String.fromCharCode(((code - 65 + 13) % 26) + 65);
          if (code >= 97 && code <= 122) return String.fromCharCode(((code - 97 + 13) % 26) + 97);
          return character;
        });
      };
    }
    if (name === "entities") {
      return {
        encodeHTML: function (text) {
          return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;")
            .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
        },
        escapeUTF8: function (text) {
          return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;")
            .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")
            .replace(/[^\x00-\x7F]/g, function (character) {
              return "&#" + character.codePointAt(0) + ";";
            });
        },
        decodeHTML: function (text) {
          return String(text)
            .replace(/&#x([0-9a-f]+);/gi, function (_, hex) { return String.fromCodePoint(parseInt(hex, 16)); })
            .replace(/&#(\d+);/g, function (_, dec) { return String.fromCodePoint(parseInt(dec, 10)); })
            .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
            .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
        }
      };
    }

    if (name === "linkedom") {
      return {
        parseHTML: function (html) {
          function links() {
            var output = [];
            var regex = /<a\b[^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*>/gi;
            var match;
            while ((match = regex.exec(String(html))) !== null) {
              output.push({ href: match[1]
                .replace(/&amp;/g, "&")
                .replace(/&quot;/g, '"')
                .replace(/&#39;/g, "'")
                .replace(/&lt;/g, "<")
                .replace(/&gt;/g, ">") });
            }
            return output;
          }
          return {
            document: {
              querySelectorAll: function (selector) {
                return String(selector).toLowerCase() === "a" ? links() : [];
              },
              getElementsByTagName: function (tag) {
                return String(tag).toLowerCase() === "a" ? links() : [];
              }
            }
          };
        }
      };
    }
    if (name.indexOf("@popclip/helpers/") === 0) {
      var helper = name.slice("@popclip/helpers/".length);
      return global.__bubbleHelpers[helper] || {};
    }
    if (global.__bubbleModuleCache[name]) return global.__bubbleModuleCache[name];
    var text = __bubbleReadModule(String(name));
    if (text === null || typeof text === "undefined") {
      throw new Error("Cannot find module: " + name);
    }
    if (/\.json$/i.test(name)) {
      var parsed = JSON.parse(text);
      global.__bubbleModuleCache[name] = parsed;
      return parsed;
    }
    var localModule = { exports: {} };
    global.__bubbleLastDefine = undefined;
    (new Function("module", "exports", "require", text))(localModule, localModule.exports, global.require);
    var defined = global.__bubbleLastDefine;
    global.__bubbleLastDefine = undefined;
    global.__bubbleModuleCache[name] = defined !== undefined ? defined : localModule.exports;
    return global.__bubbleModuleCache[name];
  };

  /* ---------- action resolution ---------- */
  // The native bridge returns a fresh input dictionary on each access. Use a
  // Proxy so `input.data.urls.ranges` can be attached while keeping native
  // method receivers intact.
  try {
    if (global.popclip && typeof global.popclip === "object" && typeof Proxy === "function") {
      var nativePopclip = global.popclip;
      global.popclip = new Proxy(nativePopclip, {
        get: function (target, property) {
          if (property === "signInRequiredError") {
            return function () {
              return new Error(global.__bubbleAuthError || "This extension requires you to sign in first.");
            };
          }
          if (property === "settingsRequiredError") {
            return function () {
              return new Error(global.__bubbleSettingsError || "This extension needs additional settings.");
            };
          }
          if (property === "input") {
            var input = target.input;
            try {
              if (input && input.data && Array.isArray(input.data.urls)) {
                input.data.urls.ranges = input.data.urlRanges || [];
              }
            } catch (error) {}
            return input;
          }
          var value = target[property];
          if (typeof value === "function") return value.bind(target);
          return value;
        }
      });
    }
  } catch (error) {}

  global.__bubbleResolveAction = async function () {
    var ex = (global.module && global.module.exports && Object.keys(global.module.exports).length)
      ? global.module.exports
      : global.exports;
    if (!ex) ex = {};
    if (ex.default && typeof ex.default === "object" &&
        (ex.default.actions !== undefined || ex.default.action !== undefined)) {
      ex = ex.default;
    }
    var captured = global.__bubbleCaptured.length
      ? global.__bubbleCaptured[global.__bubbleCaptured.length - 1]
      : null;
    var reference = String(global.__bubbleRef || "exportAction");
    var title = String(global.__bubbleTitle || "");
    var input = global.popclip ? global.popclip.input : {};
    var options = global.popclip ? global.popclip.options : {};

    async function list(value) {
      if (typeof value === "function") value = value(input, options, global.popclip ? global.popclip.context : {});
      value = await value;
      if (value === undefined || value === null) return [];
      if (!Array.isArray(value)) value = [value];
      return value;
    }
    function findInSubmenu(action, wantedTitle) {
      if (!action || !Array.isArray(action.submenu)) return action;
      var children = action.submenu;
      if (wantedTitle) {
        for (var i = 0; i < children.length; i++) {
          var child = children[i];
          var childTitle = child && child.title;
          if (childTitle && typeof childTitle === "object") {
            childTitle = childTitle[preferredLanguage] || childTitle.en;
          }
          if (String(childTitle || "") === wantedTitle) {
            return findInSubmenu(child, wantedTitle) || child;
          }
          if (child && Array.isArray(child.submenu)) {
            var nested = findInSubmenu(child, wantedTitle);
            if (nested && nested !== child) return nested;
          }
        }
      }
      for (var j = 0; j < children.length; j++) {
        var candidate = children[j];
        if (candidate && (typeof candidate.code === "function" || typeof candidate.action === "function")) return candidate;
        if (candidate && Array.isArray(candidate.submenu)) {
          var found = findInSubmenu(candidate, wantedTitle);
          if (found && found !== candidate) return found;
        }
      }
      return action;
    }
    function pick(items) {
      if (!items.length) return null;
      if (title) {
        for (var i = 0; i < items.length; i++) {
          var itemTitle = items[i] && items[i].title;
          if (itemTitle && typeof itemTitle === "object") itemTitle = itemTitle[preferredLanguage] || itemTitle.en;
          if (String(itemTitle || "") === title) return findInSubmenu(items[i], title);
        }
      }
      var index = 0;
      var parts = reference.split(":");
      if (parts.length === 2) index = parseInt(parts[1], 10) || 0;
      return findInSubmenu(items[index] || items[0] || null, title);
    }

    if (reference.indexOf("definedAction") === 0 && captured) {
      return pick(await list(captured.actions));
    }
    if (reference === "definedSingle" && captured) return findInSubmenu(captured.action || null, title);
    if (reference === "exportActions") return pick(await list(ex.actions));
    if (reference === "exportDefault") return findInSubmenu(ex.default || null, title);
    if (reference === "exportAction") return findInSubmenu(ex.action || null, title);

    if (captured) {
      if (captured.actions !== undefined) return pick(await list(captured.actions));
      if (captured.action !== undefined) return findInSubmenu(captured.action, title);
    }
    if (ex.actions !== undefined) return pick(await list(ex.actions));
    if (ex.action !== undefined) return findInSubmenu(ex.action, title);
    if (ex.default !== undefined) return findInSubmenu(ex.default, title);
    if (typeof global.module.exports === "function") return global.module.exports;
    return null;
  };
})(this);
