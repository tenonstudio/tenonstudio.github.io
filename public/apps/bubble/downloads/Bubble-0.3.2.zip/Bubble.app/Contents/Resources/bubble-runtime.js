/* Bubble's native extension runtime (API v1). */
(function (global) {
  "use strict";

  function parseJSON(value, fallback) {
    try { return value ? JSON.parse(value) : fallback; } catch (error) { return fallback; }
  }

  var permissions = {};
  (parseJSON(global.__bubblePermissions, []) || []).forEach(function (permission) {
    permissions[permission] = true;
  });
  function requirePermission(permission) {
    if (!permissions[permission]) {
      var error = new Error("Permission denied: " + permission + ". Declare it in BubbleExtension.json.");
      error.name = "PermissionError";
      throw error;
    }
  }

  var input = parseJSON(global.__bubbleInput, {});
  var context = parseJSON(global.__bubbleContext, {});
  var options = parseJSON(global.__bubbleOptions, {});
  var modifiers = parseJSON(global.__bubbleModifiers, {});
  var extension = parseJSON(global.__bubbleExtension, {});

  function log() {
    var parts = [];
    for (var i = 0; i < arguments.length; i++) {
      var value = arguments[i];
      try { parts.push(typeof value === "object" ? JSON.stringify(value) : String(value)); }
      catch (error) { parts.push(String(value)); }
    }
    try { __bubbleLog(parts.join(" ")); } catch (error) {}
  }
  global.print = log;

  function permissionError(permission) {
    var error = new Error("Permission denied: " + permission);
    error.name = "PermissionError";
    return error;
  }

  var bubble = {
    apiVersion: 1,
    extension: extension,
    input: input,
    context: context,
    options: options,
    modifiers: modifiers,

    copyText: function (text, copyOptions) {
      requirePermission("clipboard.write");
      if (!__bubbleCopyText(String(text))) throw new Error("Could not write to the clipboard.");
      return Promise.resolve();
    },
    pasteText: function (text, pasteOptions) {
      requirePermission("clipboard.write");
      if (!__bubblePasteText(String(text))) throw new Error("Could not write to the clipboard.");
      return Promise.resolve();
    },
    showText: function (text) {
      __bubbleShowText(String(text));
    },
    showStatus: function (text) {
      __bubbleShowStatus(text ? String(text) : "");
    },
    showSuccess: function () { __bubbleShowStatus(""); },
    showFailure: function () { __bubbleShowFailure(); },
    openUrl: function (url, openOptions) {
      requirePermission("apps.open");
      if (!__bubbleOpenUrl(String(url), JSON.stringify(openOptions || {}))) {
        throw new Error("Could not open URL: " + url);
      }
      return Promise.resolve();
    },
    fetch: function (url, init) {
      requirePermission("network");
      var request = init || {};
      var headers = request.headers || {};
      var body = request.body === undefined || request.body === null ? null : String(request.body);
      return new Promise(function (resolve, reject) {
        var raw = __bubbleHTTP(
          String(request.method || "GET").toUpperCase(),
          String(url),
          body,
          JSON.stringify(headers)
        );
        var response = parseJSON(raw, null);
        if (!response) { reject(new Error("Network request failed.")); return; }
        if (response.error) { reject(new Error(response.error)); return; }
        resolve({
          ok: response.status >= 200 && response.status < 300,
          status: response.status,
          url: String(url),
          headers: response.headers || {},
          text: function () {
            return Promise.resolve(typeof response.data === "string" ? response.data : JSON.stringify(response.data));
          },
          json: function () {
            return Promise.resolve(typeof response.data === "string" ? parseJSON(response.data, null) : response.data);
          }
        });
      });
    },
    request: function (request) {
      requirePermission("network");
      var raw = __bubbleHTTP(
        String(request.method || "GET").toUpperCase(),
        String(request.url),
        request.body === undefined || request.body === null ? null : String(request.body),
        JSON.stringify(request.headers || {})
      );
      var response = parseJSON(raw, null);
      if (!response) throw new Error("Network request failed.");
      if (response.error) throw new Error(response.error);
      if (response.status >= 400) {
        var error = new Error("HTTP " + response.status);
        error.response = response;
        throw error;
      }
      return Promise.resolve(response);
    },
    runShell: function (script, shellOptions) {
      requirePermission("shell");
      var raw = __bubbleShell(String(script), JSON.stringify(shellOptions || {}));
      var result = parseJSON(raw, null);
      if (!result) throw new Error("Shell command failed.");
      if (result.error) throw new Error(result.error);
      return Promise.resolve(result);
    },
    runAppleScript: function (source) {
      requirePermission("automation");
      var result = __bubbleAppleScript(String(source));
      if (result === null) throw new Error("AppleScript failed.");
      return Promise.resolve(result);
    },
    runShortcut: function (name) {
      requirePermission("automation");
      var result = __bubbleShortcut(String(name));
      if (result === null) throw new Error("Shortcut failed.");
      return Promise.resolve(result);
    },
    performService: function (name) {
      requirePermission("automation");
      if (!__bubbleService(String(name))) throw new Error("Service is not available.");
      return Promise.resolve();
    },
    pressKey: function (combo) {
      requirePermission("automation");
      if (!__bubblePressKey(String(combo))) throw new Error("Unsupported key combo.");
      return Promise.resolve();
    },
    openSettings: function () {
      __bubbleOpenSettings();
    },
    log: log
  };

  bubble.clipboard = {
    readText: function () {
      requirePermission("clipboard.read");
      return __bubbleClipboardRead() || "";
    },
    writeText: function (text) {
      requirePermission("clipboard.write");
      if (!__bubbleCopyText(String(text))) throw new Error("Could not write to the clipboard.");
    }
  };

  bubble.storage = {
    get: function (key, fallback) {
      requirePermission("storage");
      var value = __bubbleStorageGet(String(key));
      if (value === null || typeof value === "undefined") return fallback;
      return parseJSON(value, value);
    },
    set: function (key, value) {
      requirePermission("storage");
      __bubbleStorageSet(String(key), JSON.stringify(value));
    },
    remove: function (key) {
      requirePermission("storage");
      __bubbleStorageRemove(String(key));
    }
  };

  global.bubble = bubble;
  global.input = input;
  global.context = context;
  global.options = options;
  global.modifiers = modifiers;

  var moduleCache = {};
  global.require = function (name) {
    if (moduleCache[name]) return moduleCache[name];
    if (typeof name !== "string" || name.indexOf(".") !== 0) {
      throw new Error("Only local modules can be required: " + name);
    }
    var text = __bubbleReadModule(name);
    if (text === null || typeof text === "undefined") {
      throw new Error("Cannot find module: " + name);
    }
    if (/\.json$/i.test(name)) {
      var parsed = JSON.parse(text);
      moduleCache[name] = parsed;
      return parsed;
    }
    var localModule = { exports: {} };
    (new Function("module", "exports", "require", text))(localModule, localModule.exports, global.require);
    moduleCache[name] = localModule.exports;
    return localModule.exports;
  };
})(this);
