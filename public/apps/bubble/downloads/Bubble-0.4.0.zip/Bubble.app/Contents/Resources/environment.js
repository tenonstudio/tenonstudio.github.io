// Bubble JavaScript environment polyfills. The native host installs
// __bubbleSchedule, __bubbleCancel, __bubbleBase64Encode/Decode and __bubbleHTTP
// before this file is evaluated.
function btoa(input) {
    return __bubbleBase64Encode(String(input));
}
function atob(input) {
    return __bubbleBase64Decode(String(input));
}
function __requirePermission(permission) {
    const allowed = globalThis.__bubblePermissions;
    if (!Array.isArray(allowed) || !allowed.includes(permission)) {
        const error = new Error("Permission denied: " + permission);
        error.name = "PermissionError";
        throw error;
    }
}
function setTimeout(callback, delay) {
    return __bubbleSchedule(callback, Number(delay) || 0, false);
}
function setInterval(callback, delay) {
    return __bubbleSchedule(callback, Number(delay) || 0, true);
}
function clearTimeout(id) {
    if (id != null)
        __bubbleCancel(Number(id));
}
function clearInterval(id) {
    if (id != null)
        __bubbleCancel(Number(id));
}
function sleep(milliseconds) {
    return new Promise(function (resolve) {
        setTimeout(resolve, Number(milliseconds) || 0);
    });
}
function structuredClone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}
class TextEncoder {
    encode(input) {
        const text = String(input);
        const bytes = [];
        for (let i = 0; i < text.length; i++) {
            let code = text.charCodeAt(i);
            if (code < 0x80) {
                bytes.push(code);
            }
            else if (code < 0x800) {
                bytes.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f));
            }
            else if (code >= 0xd800 && code <= 0xdbff) {
                const next = text.charCodeAt(++i);
                code = 0x10000 + ((code - 0xd800) << 10) + (next - 0xdc00);
                bytes.push(0xf0 | (code >> 18), 0x80 | ((code >> 12) & 0x3f), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
            }
            else {
                bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
            }
        }
        return new Uint8Array(bytes);
    }
}
class TextDecoder {
    decode(bytes) {
        const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
        let result = "";
        for (let i = 0; i < data.length;) {
            const byte = data[i++];
            if (byte < 0x80) {
                result += String.fromCharCode(byte);
            }
            else if (byte < 0xe0) {
                result += String.fromCharCode(((byte & 0x1f) << 6) | (data[i++] & 0x3f));
            }
            else if (byte < 0xf0) {
                result += String.fromCharCode(((byte & 0x0f) << 12) | ((data[i++] & 0x3f) << 6) | (data[i++] & 0x3f));
            }
            else {
                const code = ((byte & 0x07) << 18) | ((data[i++] & 0x3f) << 12)
                    | ((data[i++] & 0x3f) << 6) | (data[i++] & 0x3f);
                const adjusted = code - 0x10000;
                result += String.fromCharCode(0xd800 + (adjusted >> 10), 0xdc00 + (adjusted & 0x3ff));
            }
        }
        return result;
    }
}
const __b64Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function __bytesToBase64(bytes) {
    let output = "";
    for (let i = 0; i < bytes.length; i += 3) {
        const a = bytes[i];
        const b = i + 1 < bytes.length ? bytes[i + 1] : 0;
        const c = i + 2 < bytes.length ? bytes[i + 2] : 0;
        output += __b64Alphabet[a >> 2];
        output += __b64Alphabet[((a & 3) << 4) | (b >> 4)];
        output += i + 1 < bytes.length ? __b64Alphabet[((b & 15) << 2) | (c >> 6)] : "=";
        output += i + 2 < bytes.length ? __b64Alphabet[c & 63] : "=";
    }
    return output;
}
function __base64ToBytes(value) {
    let text = String(value)
        .replace(/-/g, "+")
        .replace(/_/g, "/")
        .replace(/[^A-Za-z0-9+/=]/g, "");
    while (text.length % 4 !== 0)
        text += "=";
    const bytes = [];
    for (let i = 0; i < text.length; i += 4) {
        const a = __b64Alphabet.indexOf(text[i]);
        const b = __b64Alphabet.indexOf(text[i + 1]);
        const c = text[i + 2] === "=" ? 0 : __b64Alphabet.indexOf(text[i + 2]);
        const d = text[i + 3] === "=" ? 0 : __b64Alphabet.indexOf(text[i + 3]);
        if (a < 0 || b < 0)
            continue;
        bytes.push((a << 2) | (b >> 4));
        if (text[i + 2] !== "=")
            bytes.push(((b & 15) << 4) | (c >> 2));
        if (text[i + 3] !== "=")
            bytes.push(((c & 3) << 6) | d);
    }
    return new Uint8Array(bytes);
}
function __bytesFromString(value, encoding) {
    const normalized = (encoding || "utf8").toLowerCase();
    if (normalized === "hex") {
        const bytes = [];
        for (let i = 0; i + 1 < value.length; i += 2) {
            bytes.push(parseInt(value.slice(i, i + 2), 16));
        }
        return new Uint8Array(bytes);
    }
    if (normalized === "base64" || normalized === "base64url") {
        return __base64ToBytes(value);
    }
    if (normalized === "ascii" || normalized === "latin1" || normalized === "binary") {
        return new Uint8Array(Array.from(value, char => char.charCodeAt(0) & 0xff));
    }
    return new TextEncoder().encode(value);
}
// @ts-ignore Node Buffer.from intentionally differs from Uint8Array.from.
class BubbleBuffer extends Uint8Array {
    static from(value, encoding) {
        if (typeof value === "string") {
            return new BubbleBuffer(__bytesFromString(value, encoding));
        }
        if (value instanceof ArrayBuffer) {
            return new BubbleBuffer(new Uint8Array(value));
        }
        if (ArrayBuffer.isView(value)) {
            return new BubbleBuffer(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
        }
        if (value && typeof value === "object" && typeof value.length === "number") {
            return new BubbleBuffer(Uint8Array.from(value));
        }
        return new BubbleBuffer();
    }
    static fromString(value, encoding) {
        return new BubbleBuffer(__bytesFromString(value, encoding));
    }
    static alloc(size, fill, encoding) {
        const buffer = new BubbleBuffer(new Uint8Array(Math.max(0, Number(size) || 0)));
        if (fill !== undefined)
            buffer.fill(fill, 0, buffer.length, encoding);
        return buffer;
    }
    static allocUnsafe(size) {
        return BubbleBuffer.alloc(size);
    }
    static concat(list, totalLength) {
        const length = totalLength ?? Array.from(list).reduce((sum, item) => sum + item.length, 0);
        const result = BubbleBuffer.alloc(length);
        let offset = 0;
        for (const item of Array.from(list)) {
            const bytes = new Uint8Array(item.buffer, item.byteOffset, item.byteLength);
            result.set(bytes, offset);
            offset += bytes.length;
        }
        return result;
    }
    static isBuffer(value) {
        return value instanceof BubbleBuffer;
    }
    static byteLength(value, encoding) {
        return __bytesFromString(String(value), encoding).length;
    }
    // @ts-ignore Node's Buffer.toString signature differs from Uint8Array.
    toString(encoding, start, end) {
        const normalized = (encoding || "utf8").toLowerCase();
        const begin = Math.max(0, start ?? 0);
        const finish = Math.max(begin, end ?? this.length);
        const bytes = this.subarray(begin, finish);
        if (normalized === "hex") {
            return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
        }
        if (normalized === "base64" || normalized === "base64url") {
            const value = __bytesToBase64(bytes);
            return normalized === "base64url"
                ? value.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
                : value;
        }
        if (normalized === "ascii" || normalized === "latin1" || normalized === "binary") {
            return Array.from(bytes, byte => String.fromCharCode(byte)).join("");
        }
        return new TextDecoder().decode(bytes);
    }
    // @ts-ignore Uint8Array returns Uint8Array for slice.
    slice(start, end) {
        return new BubbleBuffer(this.subarray(start, end));
    }
    // @ts-ignore Uint8Array returns Uint8Array for subarray.
    subarray(start, end) {
        return new BubbleBuffer(new Uint8Array(this.buffer, this.byteOffset + (start ?? 0), Math.max(0, (end ?? this.length) - (start ?? 0))));
    }
    equals(other) {
        if (this.length !== other.length)
            return false;
        for (let i = 0; i < this.length; i++)
            if (this[i] !== other[i])
                return false;
        return true;
    }
    compare(other) {
        const length = Math.min(this.length, other.length);
        for (let i = 0; i < length; i++) {
            if (this[i] !== other[i])
                return this[i] < other[i] ? -1 : 1;
        }
        return this.length === other.length ? 0 : this.length < other.length ? -1 : 1;
    }
    write(value, offset = 0, length, encoding) {
        const bytes = __bytesFromString(String(value), encoding);
        const count = Math.min(bytes.length, length ?? this.length - offset);
        this.set(bytes.subarray(0, count), Math.max(0, offset));
        return count;
    }
    fill(value, start, end, encoding) {
        if (typeof value === "string") {
            const pattern = __bytesFromString(value, encoding);
            if (pattern.length === 0)
                return this;
            for (let i = start ?? 0; i < (end ?? this.length); i++) {
                this[i] = pattern[(i - (start ?? 0)) % pattern.length];
            }
            return this;
        }
        return super.fill(value ?? 0, start, end);
    }
    copy(target, targetStart = 0, sourceStart = 0, sourceEnd = this.length) {
        const bytes = this.subarray(sourceStart, sourceEnd);
        target.set(bytes, targetStart);
        return bytes.length;
    }
    readUInt8(offset = 0) { return this[offset]; }
    readInt8(offset = 0) { return (this[offset] << 24) >> 24; }
    readUInt16LE(offset = 0) { return this[offset] | (this[offset + 1] << 8); }
    readUInt16BE(offset = 0) { return (this[offset] << 8) | this[offset + 1]; }
    readInt16LE(offset = 0) { return (this.readUInt16LE(offset) << 16) >> 16; }
    readInt16BE(offset = 0) { return (this.readUInt16BE(offset) << 16) >> 16; }
    readUInt32LE(offset = 0) {
        return (this[offset] | (this[offset + 1] << 8) | (this[offset + 2] << 16) | (this[offset + 3] << 24)) >>> 0;
    }
    readUInt32BE(offset = 0) {
        return ((this[offset] << 24) | (this[offset + 1] << 16) | (this[offset + 2] << 8) | this[offset + 3]) >>> 0;
    }
    writeUInt8(value, offset = 0) { this[offset] = value & 0xff; return offset + 1; }
    writeUInt16LE(value, offset = 0) {
        this[offset] = value & 0xff;
        this[offset + 1] = (value >> 8) & 0xff;
        return offset + 2;
    }
    writeUInt16BE(value, offset = 0) {
        this[offset] = (value >> 8) & 0xff;
        this[offset + 1] = value & 0xff;
        return offset + 2;
    }
    writeUInt32LE(value, offset = 0) {
        this[offset] = value & 0xff;
        this[offset + 1] = (value >> 8) & 0xff;
        this[offset + 2] = (value >> 16) & 0xff;
        this[offset + 3] = (value >> 24) & 0xff;
        return offset + 4;
    }
    writeUInt32BE(value, offset = 0) {
        this[offset] = (value >> 24) & 0xff;
        this[offset + 1] = (value >> 16) & 0xff;
        this[offset + 2] = (value >> 8) & 0xff;
        this[offset + 3] = value & 0xff;
        return offset + 4;
    }
    toJSON() { return { type: "Buffer", data: Array.from(this) }; }
}
globalThis.Buffer = BubbleBuffer;
class BubbleBlob {
    constructor(parts, options) {
        const chunks = [];
        for (const part of parts || []) {
            if (typeof part === "string")
                chunks.push(new TextEncoder().encode(part));
            else if (part instanceof ArrayBuffer)
                chunks.push(new Uint8Array(part));
            else if (ArrayBuffer.isView(part)) {
                chunks.push(new Uint8Array(part.buffer, part.byteOffset, part.byteLength));
            }
            else if (part instanceof BubbleBlob)
                chunks.push(part._bytes);
            else
                chunks.push(new TextEncoder().encode(String(part)));
        }
        this._bytes = BubbleBuffer.concat(chunks);
        this.type = (options && options.type) || "";
    }
    get size() { return this._bytes.length; }
    text() { return Promise.resolve(new TextDecoder().decode(this._bytes)); }
    arrayBuffer() {
        return Promise.resolve(this._bytes.slice().buffer);
    }
    bytes() { return Promise.resolve(this._bytes.slice()); }
    slice(start, end, type) {
        return new BubbleBlob([this._bytes.subarray(start, end)], { type: type ?? this.type });
    }
}
globalThis.Blob = BubbleBlob;
class BubbleURLSearchParams {
    constructor(init) {
        this._values = [];
        if (typeof init === "string") {
            const text = init.charAt(0) === "?" ? init.slice(1) : init;
            if (text) {
                for (const pair of text.split("&")) {
                    const pieces = pair.split("=");
                    this.append(decodeURIComponent(pieces[0] || ""), decodeURIComponent(pieces[1] || ""));
                }
            }
        }
        else if (init && typeof init === "object") {
            for (const key of Object.keys(init))
                this.append(key, init[key]);
        }
    }
    append(key, value) { this._values.push([String(key), String(value)]); }
    set(key, value) {
        this.delete(key);
        this.append(key, value);
    }
    get(key) {
        const pair = this._values.find(value => value[0] === String(key));
        return pair ? pair[1] : null;
    }
    getAll(key) {
        return this._values.filter(value => value[0] === String(key)).map(value => value[1]);
    }
    has(key) { return this.get(key) !== null; }
    delete(key) { this._values = this._values.filter(value => value[0] !== String(key)); }
    toString() {
        return this._values.map(value => `${encodeURIComponent(value[0])}=${encodeURIComponent(value[1])}`).join("&");
    }
}
globalThis.URLSearchParams = BubbleURLSearchParams;
class BubbleURL {
    constructor(input, base) {
        let value = String(input);
        if (base && !/^[a-z][a-z0-9+.-]*:/i.test(value)) {
            const parent = new BubbleURL(base);
            value = parent.origin + (value.charAt(0) === "/" ? value : "/" + value);
        }
        const match = value.match(/^([a-z][a-z0-9+.-]*:)?\/\/([^/?#]*)([^?#]*)(\?[^#]*)?(#.*)?$/i);
        if (!match)
            throw new TypeError("Invalid URL");
        this.protocol = match[1] || "https:";
        const authority = match[2] || "";
        const hostPort = authority.split("@").pop();
        this.hostname = hostPort.split(":")[0];
        this.port = hostPort.split(":")[1] || "";
        this.pathname = match[3] || "/";
        this.search = match[4] || "";
        this.hash = match[5] || "";
        this.host = this.hostname + (this.port ? ":" + this.port : "");
        this.origin = this.protocol + "//" + this.host;
        this.searchParams = new BubbleURLSearchParams(this.search);
    }
    toString() {
        let path = this.pathname || "/";
        return this.origin + path + this.search + this.hash;
    }
}
globalThis.URL = BubbleURL;
class BubbleXMLHttpRequest {
    constructor() {
        this.readyState = 0;
        this.status = 0;
        this.statusText = "";
        this.responseText = "";
        this.response = null;
        this.responseType = "";
        this.responseURL = "";
        this.timeout = 0;
        this.withCredentials = false;
        this.upload = {};
        this.onreadystatechange = null;
        this.onloadstart = null;
        this.onprogress = null;
        this.onload = null;
        this.onloadend = null;
        this.onerror = null;
        this.ontimeout = null;
        this.onabort = null;
        this._method = "GET";
        this._url = "";
        this._headers = {};
        this._responseHeaders = {};
        this._done = false;
    }
    open(method, url) {
        this._method = String(method || "GET").toUpperCase();
        this._url = String(url);
        this.responseURL = this._url;
        this._done = false;
        this.readyState = 1;
        this._changed();
    }
    setRequestHeader(name, value) {
        if (this.readyState !== 1)
            throw new Error("XMLHttpRequest is not open.");
        this._headers[String(name)] = String(value);
    }
    getResponseHeader(name) {
        return this._responseHeaders[String(name).toLowerCase()] || null;
    }
    getAllResponseHeaders() {
        return Object.keys(this._responseHeaders)
            .map(name => `${name}: ${this._responseHeaders[name]}`)
            .join("\r\n");
    }
    send(body) {
        if (this.readyState !== 1)
            throw new Error("XMLHttpRequest is not open.");
        __requirePermission("network");
        this.readyState = 2;
        this._changed();
        if (typeof this.onloadstart === "function")
            this.onloadstart();
        try {
            const response = __bubbleHTTP(this._method, this._url, body == null ? null : String(body), JSON.stringify(this._headers));
            if (!response)
                throw new Error("The request failed.");
            this.status = Number(response.status) || 0;
            this.statusText = String(response.statusText || "");
            this._responseHeaders = response.headers || {};
            this.responseText = String(response.body || "");
            this.responseURL = this._url;
            const contentType = this.getResponseHeader("content-type") || "";
            const bytes = response.bodyBase64 ? __base64ToBytes(response.bodyBase64) : __bytesFromString(this.responseText);
            if (this.responseType === "json") {
                try {
                    this.response = this.responseText ? JSON.parse(this.responseText) : null;
                }
                catch {
                    this.response = null;
                }
            }
            else if (this.responseType === "arraybuffer") {
                this.response = bytes.slice().buffer;
            }
            else if (this.responseType === "blob") {
                this.response = new BubbleBlob([bytes], { type: contentType });
            }
            else if (this.responseType === "text" || this.responseType === "") {
                this.response = this.responseText;
            }
            else {
                this.response = this.responseText;
            }
            this._done = true;
            this.readyState = 4;
            this._changed();
            if (typeof this.onprogress === "function") {
                this.onprogress({ lengthComputable: false, loaded: bytes.length, total: 0 });
            }
            if (typeof this.onload === "function")
                this.onload();
            if (typeof this.onloadend === "function")
                this.onloadend();
        }
        catch (error) {
            this._fail(error);
        }
    }
    abort() {
        if (this._done)
            return;
        this._done = true;
        this.readyState = 0;
        if (typeof this.onabort === "function")
            this.onabort();
        if (typeof this.onloadend === "function")
            this.onloadend();
    }
    _fail(error) {
        this.status = 0;
        this.statusText = "";
        this.responseText = "";
        this.response = null;
        this._done = true;
        this.readyState = 4;
        this._changed();
        if (typeof this.onerror === "function")
            this.onerror();
        if (typeof this.onloadend === "function")
            this.onloadend();
    }
    _changed() {
        if (typeof this.onreadystatechange === "function")
            this.onreadystatechange();
    }
}
class BubbleRichString {
    constructor(source, options) {
        const format = (options && options.format) || "rtf";
        const text = String(source || "");
        const value = __bubbleRichString(text, format);
        this.rtf = value.rtf || (format === "rtf" ? text : "");
        this.html = value.html || (format === "html" ? text : "");
    }
}
globalThis.RichString = BubbleRichString;
function shellEscape(value) {
    if (value && typeof value === "object" && "toString" in value) {
        return shellEscape(value.toString());
    }
    return "'" + String(value).replace(/'/g, "'\\''") + "'";
}
function __shellResult(raw) {
    const stdout = String(raw?.stdout ?? "");
    const stderr = String(raw?.stderr ?? "");
    const status = Number(raw?.status ?? 0);
    return {
        stdout,
        stderr,
        status,
        toString() { return stdout.replace(/\n+$/, ""); }
    };
}
function __shellRun(strings, values, options) {
    __requirePermission("shell");
    const config = options || {};
    const quote = typeof config.quote === "function" ? config.quote : shellEscape;
    const prefix = config.prefix === undefined ? "set -euo pipefail" : config.prefix;
    let command = String(strings[0] ?? "");
    for (let index = 0; index < values.length; index++) {
        const value = values[index];
        const pieces = Array.isArray(value) ? value : [value];
        command += pieces.map(quote).join(" ") + String(strings[index + 1] ?? "");
    }
    if (prefix)
        command = prefix + "\n" + command;
    const raw = __bubbleShell(command, config.interpreter || null, config.env ? JSON.stringify(config.env) : null, config.shellMode || null);
    if (!raw)
        return Promise.reject(new Error("Shell execution failed."));
    return Promise.resolve(__shellResult(raw));
}
function $(first, ...rest) {
    if (first && typeof first === "object" && !Array.isArray(first) && !("raw" in first)) {
        const options = first;
        return (strings, ...values) => __shellRun(strings, values, options);
    }
    return __shellRun(first, rest, {});
}
function defineExtension(extension) {
    globalThis.module.exports = extension;
}
function require(identifier) {
    const value = globalThis.__bubbleRequire?.(String(identifier));
    if (value === undefined) {
        throw new Error("Cannot find module: " + identifier);
    }
    return value;
}
var window = globalThis;
globalThis.XMLHttpRequest = BubbleXMLHttpRequest;
