// Bubble action module.
const spellingMinLength = 3;
const spellingMaxLength = 400;
const spellingGuessLimit = 5;
const allowedSpellingWords = new Set(["pilotmoon", "popclip"]);
function spellingWord(text) {
    const word = text.trim();
    if (word.length < spellingMinLength || word.length > spellingMaxLength)
        return null;
    if (/\s/.test(word) || /[a-z][A-Z]/.test(word) || /[:_@]/.test(word))
        return null;
    if (allowedSpellingWords.has(word.toLowerCase()))
        return null;
    return word;
}
function languageLookup() {
    const lookup = {};
    for (const language of bubble.util.getSpellingLanguages()) {
        lookup[language.code] = language.name;
    }
    return lookup;
}
module.exports = {
    definition: {
        identifier: "bubble.builtin.spelling",
        name: { en: "Spelling", "zh-Hans": "拼写" },
        description: {
            en: "Show spelling suggestions for the selected word.",
            "zh-Hans": "为选中的单词显示拼写建议。"
        },
        icon: "textformat.abc",
        showAs: "icon",
        requirements: ["text"],
        permissions: [],
        options: [
            {
                identifier: "spellingLanguage",
                type: "spelling-language",
                label: { en: "Language 1", "zh-Hans": "语言 1" }
            },
            {
                identifier: "spellingLanguage2",
                type: "spelling-language",
                label: { en: "Language 2", "zh-Hans": "语言 2" },
                allowNone: true
            }
        ]
    },
    isAvailable(input, context, _options, util) {
        const text = String(input.text || "").trim();
        if (!context.canCut || text.length < 3 || text.length > 400)
            return false;
        if (/\s/.test(text) || /[a-z][A-Z]/.test(text) || /[:_@]/.test(text))
            return false;
        if (["pilotmoon", "popclip"].includes(text.toLowerCase()))
            return false;
        return util.getPreferredSpellingLanguages().some((language) => {
            if (util.checkSpelling(text, { language }))
                return false;
            return util.getSpellingGuesses(text, { language, limit: 5 }).length > 0;
        });
    },
    perform() {
        const word = spellingWord(bubble.input.text);
        if (!word)
            return;
        const available = new Set(bubble.util.getSpellingLanguages().map(language => language.code));
        const preferred = bubble.util.getPreferredSpellingLanguages();
        const names = languageLookup();
        const codes = [];
        for (const code of [
            String(bubble.options.spellingLanguage || preferred[0]),
            String(bubble.options.spellingLanguage2 || "")
        ]) {
            if (code && available.has(code) && !codes.includes(code)) {
                codes.push(code);
            }
        }
        if (codes.length === 0)
            return;
        const groups = [];
        for (const code of codes) {
            if (bubble.util.checkSpelling(word, { language: code }))
                continue;
            const guesses = bubble.util.getSpellingGuesses(word, {
                language: code,
                limit: spellingGuessLimit
            });
            if (guesses.length === 0)
                continue;
            groups.push({
                languageCode: code,
                languageName: names[code] || code,
                suggestions: guesses
            });
        }
        if (groups.length > 0) {
            bubble.showSpellingMenu(JSON.stringify(groups));
        }
    }
};
