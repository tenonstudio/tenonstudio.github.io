// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.revealInFinder",
        name: { en: "Reveal in Finder", "zh-Hans": "在 Finder 中显示" },
        description: {
            en: "Show the selected file path in Finder.",
            "zh-Hans": "在 Finder 中显示选中的文件路径。"
        },
        icon: "folder",
        showAs: "icon",
        requirements: ["text"],
        permissions: ["files.read"],
        options: []
    },
    isAvailable(input, _context, _options, _util) {
        return Array.isArray(input.data?.paths) && input.data.paths.length > 0;
    },
    perform() {
        const paths = bubble.input.data.paths;
        if (!paths.length)
            return;
        bubble.revealFile(paths[0]);
    }
};
