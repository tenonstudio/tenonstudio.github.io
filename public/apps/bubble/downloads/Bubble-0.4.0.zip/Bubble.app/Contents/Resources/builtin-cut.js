// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.cut",
        name: { en: "Cut", "zh-Hans": "剪切" },
        description: {
            en: "Remove the selection and put it on the clipboard.",
            "zh-Hans": "移除选中文本并放到剪贴板。"
        },
        icon: "scissors",
        showAs: "text",
        requirements: ["cut"],
        permissions: ["clipboard.write", "automation"],
        options: []
    },
    isAvailable(input, context, _options, _util) {
        return String(input.text || "").trim().length > 0 && Boolean(context.canCut);
    },
    perform() {
        bubble.performCommand("cut", {
            transform: bubble.modifiers.shift ? "plain" : "none"
        });
    }
};
