// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.paste",
        name: { en: "Paste", "zh-Hans": "粘贴" },
        description: {
            en: "Paste the clipboard over the selection.",
            "zh-Hans": "将剪贴板内容粘贴到选中文本上。"
        },
        icon: "doc.on.clipboard",
        showAs: "text",
        requirements: ["paste"],
        permissions: ["clipboard.write", "automation"],
        options: []
    },
    isAvailable(_input, context, _options, _util) {
        return Boolean(context.canPaste);
    },
    perform() {
        bubble.performCommand("paste", {
            transform: bubble.modifiers.shift ? "plain" : "none"
        });
    }
};
