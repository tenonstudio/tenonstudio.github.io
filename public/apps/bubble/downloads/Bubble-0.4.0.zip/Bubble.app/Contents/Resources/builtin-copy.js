// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.copy",
        name: { en: "Copy", "zh-Hans": "拷贝" },
        description: {
            en: "Copy the selection to the clipboard.",
            "zh-Hans": "将选中文本拷贝到剪贴板。"
        },
        icon: "doc.on.doc",
        showAs: "text",
        requirements: ["copy"],
        permissions: ["clipboard.write", "automation"],
        options: []
    },
    isAvailable(input, _context, _options, _util) {
        return String(input.text || "").trim().length > 0;
    },
    perform() {
        bubble.performCommand("copy", {
            transform: bubble.modifiers.shift ? "plain" : "none"
        });
    }
};
