// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.dictionary",
        name: { en: "Dictionary", "zh-Hans": "词典" },
        description: {
            en: "Look the selected word up in Dictionary.",
            "zh-Hans": "在词典中查询选中的词。"
        },
        icon: "book.closed",
        showAs: "icon",
        requirements: ["text"],
        permissions: ["clipboard.write"],
        options: []
    },
    isAvailable(input, _context, _options, util) {
        let term = String(input.text || "").trim();
        while (term && /\p{P}/u.test(term[0]))
            term = term.slice(1);
        while (term && /\p{P}/u.test(term[term.length - 1]))
            term = term.slice(0, -1);
        return term.length > 0 && term.length <= 400 && util.hasDictionaryDefinition(term);
    },
    perform() {
        let term = bubble.input.text.trim().replace(/^\p{P}+|\p{P}+$/gu, "");
        if (!term || term.length > 400)
            return;
        if (!bubble.util.hasDictionaryDefinition(term))
            return;
        if (bubble.modifiers.shift) {
            const definition = bubble.util.getDictionaryDefinition(term);
            if (!definition)
                return;
            bubble.copyText(definition);
            return;
        }
        bubble.openUrl(`dict:///${encodeURIComponent(term)}`);
    }
};
