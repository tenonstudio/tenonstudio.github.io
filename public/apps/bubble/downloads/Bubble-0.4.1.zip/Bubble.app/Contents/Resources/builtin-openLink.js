// Bubble action module.
module.exports = {
    definition: {
        identifier: "bubble.builtin.openLink",
        name: { en: "Open Link", "zh-Hans": "打开链接" },
        description: {
            en: "Open web addresses found in the selection.",
            "zh-Hans": "打开选中文本中的网址。"
        },
        icon: "link",
        showAs: "icon",
        requirements: ["url"],
        permissions: ["apps.open", "automation", "clipboard.write"],
        options: []
    },
    isAvailable(input, _context, _options, _util) {
        return (input.data?.urls?.length || 0) + (input.data?.nonHttpUrls?.length || 0) > 0;
    },
    perform() {
        const data = bubble.input.data;
        const urls = [...new Set([...(data.urls || []), ...(data.nonHttpUrls || [])])];
        if (urls.length === 0)
            return;
        if (bubble.modifiers.option) {
            bubble.copyText(urls.join("\n"));
            return;
        }
        for (const url of urls.slice(0, 25)) {
            bubble.openUrl(url, { backgroundTab: Boolean(bubble.modifiers.shift) });
        }
    }
};
