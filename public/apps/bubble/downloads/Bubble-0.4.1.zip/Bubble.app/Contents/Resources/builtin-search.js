// Bubble action module.
const searchEngines = {
    baidu: "https://www.baidu.com/s?wd=***",
    bing: "https://www.bing.com/search?q=***",
    brave: "https://search.brave.com/search?q=***",
    duckDuckGo: "https://duckduckgo.com/?q=***",
    ecosia: "https://www.ecosia.org/search?q=***",
    google: "https://www.google.com/search?q=***",
    kagi: "https://kagi.com/search?q=***",
    naver: "https://search.naver.com/search.naver?query=***",
    startpage: "https://www.startpage.com/sp/search?query=***",
    yahoo: "https://search.yahoo.com/search?p=***",
    yahooJapan: "https://search.yahoo.co.jp/search?p=***",
    yandex: "https://yandex.com/search/?text=***"
};
module.exports = {
    definition: {
        identifier: "bubble.builtin.search",
        name: { en: "Search", "zh-Hans": "搜索" },
        description: {
            en: "Search the web for the selected text.",
            "zh-Hans": "使用选中文本搜索网络。"
        },
        icon: "magnifyingglass",
        showAs: "icon",
        requirements: ["text"],
        permissions: ["apps.open", "automation"],
        options: [
            {
                identifier: "engine",
                type: "choice",
                label: { en: "Search Engine", "zh-Hans": "搜索引擎" },
                defaultValue: "google",
                values: [
                    "baidu", "bing", "brave", "duckDuckGo", "ecosia", "google",
                    "kagi", "naver", "startpage", "yahoo", "yahooJapan", "yandex",
                    "custom"
                ],
                valueLabels: {
                    baidu: "Baidu",
                    bing: "Bing",
                    brave: "Brave",
                    duckDuckGo: "DuckDuckGo",
                    ecosia: "Ecosia",
                    google: "Google",
                    kagi: "Kagi",
                    naver: "NAVER",
                    startpage: "Startpage",
                    yahoo: "Yahoo",
                    yahooJapan: "Yahoo Japan",
                    yandex: "Yandex",
                    custom: "Other…"
                }
            },
            {
                identifier: "customURL",
                type: "string",
                label: { en: "Search URL", "zh-Hans": "搜索 URL" }
            }
        ]
    },
    isAvailable(input, _context, _options, _util) {
        const text = String(input.text || "").trim();
        return text.length > 0 && text.length <= 20000;
    },
    perform() {
        const engine = String(bubble.options.engine || "google");
        const template = engine === "custom"
            ? String(bubble.options.customURL || "")
            : searchEngines[engine];
        if (!template || template.indexOf("***") < 0) {
            throw new Error("The search URL is not valid.");
        }
        if (!bubble.openTemplateUrl(template, bubble.input.text, {
            backgroundTab: Boolean(bubble.modifiers.shift),
            verbatim: Boolean(bubble.modifiers.option)
        })) {
            throw new Error("The search URL is not valid.");
        }
    }
};
