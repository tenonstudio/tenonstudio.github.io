let tileCols;
let tileSize;
let cols;
let rows;
let gridOffsetX;
let gridOffsetY;
let tileGrid;
let colorA = 255;
let colorB = 0;
let pointerX = 0;
let pointerY = 0;
let pointerTargetX = 0;
let pointerTargetY = 0;
let pointerVelocityX = 0;
let pointerVelocityY = 0;
let pointerInitialized = false;

const wallpaperSettings = {
  fps: 30,
  speed: 1,
  scale: 1,
  brightness: 1,
  theme: 'aurora'
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(min(displayDensity(), 2));
  frameRate(wallpaperSettings.fps);
  buildGrid();
  noStroke();
}

function buildGrid() {
  randomSeed(floor(random(1e9)));
  // Keep tile density stable between launches. Regeneration should change the
  // pattern, not unexpectedly change the apparent scale of the wallpaper.
  tileCols = max(12, round(24 / wallpaperSettings.scale));
  tileSize = max(24, floor(width / tileCols));
  // Draw one extra tile in each direction so fractional remainders are
  // cropped by the canvas instead of becoming visible margins.
  cols = ceil(width / tileSize) + 1;
  rows = ceil(height / tileSize) + 1;

  gridOffsetX = round((width - cols * tileSize) / 2);
  gridOffsetY = round((height - rows * tileSize) / 2);

  tileGrid = [];
  for (let row = 0; row < rows; row++) {
    tileGrid[row] = [];
    for (let col = 0; col < cols; col++) {
      const even = (col + row) % 2 === 0;
      tileGrid[row][col] = even ? random([0, 3]) : random([1, 2]);
    }
  }
}

function draw() {
  updatePointer();
  updatePalette();
  background(colorA);
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const x = gridOffsetX + col * tileSize;
      const y = gridOffsetY + row * tileSize;
      drawTruchetTile(tileGrid[row][col], x, y, tileSize);
    }
  }
}

function updatePointer() {
  if (!pointerInitialized) return;

  // A time-normalized spring-damper makes the interaction feel the same at
  // 15, 30, and 60 FPS while retaining a small, natural trailing motion.
  const dt = constrain(deltaTime / (1000 / 60), 0.25, 2);
  const stiffness = 0.035 * wallpaperSettings.speed;
  const damping = pow(0.78, dt);

  pointerVelocityX += (pointerTargetX - pointerX) * stiffness * dt;
  pointerVelocityY += (pointerTargetY - pointerY) * stiffness * dt;
  pointerVelocityX *= damping;
  pointerVelocityY *= damping;
  pointerX += pointerVelocityX * dt;
  pointerY += pointerVelocityY * dt;
}

function drawTruchetTile(variant, x, y, size) {
  push();
  const distanceToPointer = dist(x, y, pointerX, pointerY);
  const reach = max(4 * size, min(width, height) / 6) / wallpaperSettings.speed;
  const roundness = map(distanceToPointer, size, reach, size / 2, 0, true);

  translate(x, y);
  clip(() => rect(0, 0, size, size));
  rectMode(CENTER);
  noStroke();

  const fillA = variant === 0 || variant === 1 ? colorA : colorB;
  const fillB = variant === 0 || variant === 1 ? colorB : colorA;
  fill(fillA);
  rect(size / 2, size / 2, size, size);
  fill(fillB);
  if (variant === 0 || variant === 2) {
    rect(0, 0, size, size, roundness);
    rect(size, size, size, size, roundness);
  } else {
    rect(size, 0, size, size, roundness);
    rect(0, size, size, size, roundness);
  }
  pop();
}

function updatePalette() {
  const light = constrain(255 * wallpaperSettings.brightness, 0, 255);
  if (wallpaperSettings.theme === 'ocean') {
    colorA = color(205, 240, light);
    colorB = color(3, 26, 46);
  } else if (wallpaperSettings.theme === 'sunset') {
    colorA = color(light, 211, 174);
    colorB = color(62, 16, 32);
  } else if (wallpaperSettings.theme === 'monochrome') {
    colorA = color(light);
    colorB = color(38);
  } else {
    colorA = color(light);
    colorB = color(0);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  buildGrid();
}

window.wallpaper = {
  setPointer(x, y) {
    pointerTargetX = Number(x) || 0;
    pointerTargetY = Number(y) || 0;
    if (!pointerInitialized) {
      pointerX = pointerTargetX;
      pointerY = pointerTargetY;
      pointerInitialized = true;
    }
  },

  setPaused(value) {
    if (value) noLoop();
    else loop();
  },

  setFPS(value) {
    wallpaperSettings.fps = constrain(Number(value) || 30, 1, 60);
    frameRate(wallpaperSettings.fps);
  },

  applySettings(value) {
    const oldScale = wallpaperSettings.scale;
    wallpaperSettings.fps = constrain(Number(value.fps) || 30, 1, 60);
    wallpaperSettings.speed = constrain(Number(value.speed) || 1, 0.25, 2);
    wallpaperSettings.scale = constrain(Number(value.scale) || 1, 0.65, 1.25);
    wallpaperSettings.brightness = constrain(Number(value.brightness) || 1, 0.5, 1.5);
    wallpaperSettings.theme = String(value.theme || 'aurora');
    frameRate(wallpaperSettings.fps);
    if (oldScale !== wallpaperSettings.scale) buildGrid();
  },

  regenerate() {
    buildGrid();
    redraw();
  }
};
