const alphaCharacters = 'abcdefghijklmnopqrstuvwxyz0123456789@#$%&*-+=[]{};?<>';
let rain = [];
let rainCount = 70;
let glyphSize = 14;
let glyphStep = 13;

const wallpaperSettings = {
  fps: 30,
  speed: 1,
  scale: 1,
  brightness: 1,
  theme: 'aurora'
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(min(displayDensity(), 2));
  colorMode(HSB, 360, 100, 100, 100);
  textFont('Arial');
  textAlign(LEFT, BASELINE);
  frameRate(wallpaperSettings.fps);
  initializeRain();
}

function initializeRain() {
  glyphSize = 14 * wallpaperSettings.scale;
  glyphStep = 13 * wallpaperSettings.scale;
  textSize(glyphSize);

  // The source uses 70 streams at 800px wide. Scale that density to the
  // current display while keeping a sensible limit for high-resolution Macs.
  rainCount = constrain(round(70 * width / 800), 70, 220);
  rain = [];

  for (let i = 0; i < rainCount; i++) {
    const x = 5 + random(max(1, width - 10));
    const y = glyphStep + random(max(glyphStep, height - 100));
    rain.push(new CodeRain(x, y));
  }
  background(0);
}

function draw() {
  background(0);

  // Normalize the original 5-points-per-frame fade to a 60 FPS baseline.
  const fadeStep = 5 * wallpaperSettings.speed * constrain(deltaTime / (1000 / 60), 0.25, 2);
  for (const stream of rain) {
    stream.paint();
    stream.update(fadeStep);
  }
}

function currentHue() {
  if (wallpaperSettings.theme === 'ocean') return 190;
  if (wallpaperSettings.theme === 'sunset') return 34;
  if (wallpaperSettings.theme === 'monochrome') return 0;
  return 100;
}

class CodeRain {
  constructor(initialX, initialY) {
    this.letters = [];
    this.x = initialX;
    this.y = initialY;
    let initialTransparency = 5;

    for (let i = 0; i < 20; i++) {
      this.letters.push(new Code(this.x, this.y, initialTransparency));
      this.y += glyphStep;
      initialTransparency += 5;
    }
  }

  paint() {
    for (const code of this.letters) code.write();
  }

  update(fadeStep) {
    for (const code of this.letters) {
      if (code.transparency <= 0) {
        if (this.y < height + glyphStep) {
          code.move(this.x, this.y);
        } else {
          const columns = max(1, floor(width / glyphStep));
          this.x = 3 + glyphStep * floor(random(columns));
          this.y = glyphStep + glyphStep * floor(random(9));
          code.move(this.x, this.y);
        }
        this.y += glyphStep;
      } else {
        code.update(fadeStep);
      }
    }
  }
}

class Code {
  constructor(initialX, initialY, initialTransparency) {
    this.x = initialX;
    this.y = initialY;
    this.transparency = initialTransparency;
    this.character = randomCharacter();
  }

  write() {
    const hue = currentHue();
    const saturation = wallpaperSettings.theme === 'monochrome' ? 0 : 100;
    const alpha = constrain(this.transparency * wallpaperSettings.brightness, 0, 100);
    fill(hue, saturation, 100, alpha);
    text(this.character, this.x, this.y);
  }

  move(newX, newY) {
    this.x = newX;
    this.y = newY;
    this.transparency = 100;
    this.character = randomCharacter();
  }

  update(fadeStep) {
    this.transparency = max(0, this.transparency - fadeStep);
  }
}

function randomCharacter() {
  return alphaCharacters.charAt(floor(random(alphaCharacters.length)));
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  initializeRain();
}

window.wallpaper = {
  setPointer() {
    // This source-inspired version intentionally has no mouse interaction.
  },

  setPaused(value) {
    if (value) noLoop();
    else loop();
  },

  setFPS(value) {
    wallpaperSettings.fps = constrain(Number(value) || 30, 1, 60);
    frameRate(wallpaperSettings.fps);
  },

  applySettings(value) {
    const oldScale = wallpaperSettings.scale;
    wallpaperSettings.fps = constrain(Number(value.fps) || 30, 1, 60);
    wallpaperSettings.speed = constrain(Number(value.speed) || 1, 0.25, 2);
    wallpaperSettings.scale = constrain(Number(value.scale) || 1, 0.65, 1.25);
    wallpaperSettings.brightness = constrain(Number(value.brightness) || 1, 0.5, 1.5);
    wallpaperSettings.theme = String(value.theme || 'aurora');
    frameRate(wallpaperSettings.fps);
    if (oldScale !== wallpaperSettings.scale) initializeRain();
  },

  regenerate() {
    initializeRain();
  }
};
