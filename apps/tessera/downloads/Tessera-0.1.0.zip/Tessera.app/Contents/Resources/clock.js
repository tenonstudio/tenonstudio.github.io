let clock;
let angle = 0;
let nextAngle = 0;
let wallpaperPaused = false;
let pointerX = 0;
let pointerY = 0;
const hexDigits = '0123456789ABCDEF';
let animatedHexValues = null;
let hexStartValues = null;
let hexTargetValues = null;
let hexTarget = '';
let hexTransitionProgress = 1;
const hexTransitionDuration = 0.42;
let animatedColorValues = null;
let colorStartValues = null;
let colorTargetValues = null;
let colorTargetKey = '';
let colorTransitionProgress = 1;
const colorTransitionDuration = 0.8;

const wallpaperSettings = {
  fps: 30,
  speed: 1,
  scale: 1,
  brightness: 1,
  theme: 'aurora'
};

function setup() {
  try {
    setupClock();
  } catch (error) {
    window.__sketchError = String(error?.stack || error);
  }
}

function setupClock() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(min(displayDensity(), 2));
  textFont('Menlo');
  textStyle(NORMAL);
  textAlign(CENTER, CENTER);
  noStroke();
  frameRate(wallpaperSettings.fps);
  angle = radians(random(-20, 20));
  clock = new Clock();
}

function draw() {
  window.__sketchDrawCount = (window.__sketchDrawCount || 0) + 1;
  try {
    renderClock();
  } catch (error) {
    window.__sketchError = String(error?.stack || error);
    noLoop();
  }
}

function renderClock() {
  const now = new Date();
  const c = clockColor(now);
  background(c);

  const responsiveScale = min(height / 800, width / 1220) * wallpaperSettings.scale;
  push();
  translate(max(44, width * 0.045), height * 0.5);
  rotate(angle);
  scale(responsiveScale);
  textSize(50);

  angle += (nextAngle - angle) * min(0.35, 0.1 * wallpaperSettings.speed);
  clock.display(now);

  fill(255, 255 * min(1, wallpaperSettings.brightness));
  const targetHex = [red(c), green(c), blue(c)]
    .map(value => hex(round(value), 2))
    .join('');
  text(animateHex(targetHex), 680, 0);
  pop();
}

function animateHex(target) {
  const targetValues = Array.from(target, character => hexDigits.indexOf(character));
  if (!animatedHexValues || animatedHexValues.length !== targetValues.length) {
    animatedHexValues = targetValues.slice();
    hexStartValues = targetValues.slice();
    hexTargetValues = targetValues.slice();
    hexTarget = target;
    hexTransitionProgress = 1;
  }

  if (target !== hexTarget) {
    hexStartValues = animatedHexValues.slice();
    hexTargetValues = targetValues;
    hexTarget = target;
    hexTransitionProgress = 0;
  }

  hexTransitionProgress = min(
    1,
    hexTransitionProgress + constrain(deltaTime, 0, 50) / 1000 / hexTransitionDuration
  );
  // A gentle ease-out keeps the intermediate digits visible while ensuring
  // every position reaches its target at exactly the same time.
  const eased = 1 - pow(1 - hexTransitionProgress, 3);
  return hexTargetValues.map((targetValue, index) => {
    animatedHexValues[index] = lerp(hexStartValues[index], targetValue, eased);
    return hexDigits[constrain(round(animatedHexValues[index]), 0, 15)];
  }).join('');
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function rotateClockToward(x, y) {
  const centerX = max(44, width * 0.045);
  const centerY = height * 0.5;
  nextAngle = atan2(y - centerY, x - centerX);
}

// Wallpaper windows never capture macOS clicks. The host mirrors this event
// while the original click keeps passing through to Finder.
function mousePressed() {
  rotateClockToward(mouseX, mouseY);
}

function clockColor(now) {
  let r = map(now.getSeconds(), 0, 60, 0, 255);
  let g = map(now.getMinutes(), 0, 60, 0, 255);
  let b = map(now.getHours(), 0, 60, 0, 255);

  if (wallpaperSettings.theme === 'ocean') {
    [r, g, b] = [r * 0.25, g * 0.72, min(255, b * 1.9 + 28)];
  } else if (wallpaperSettings.theme === 'sunset') {
    [r, g, b] = [min(255, r * 1.25 + 28), g * 0.54, b * 0.7];
  } else if (wallpaperSettings.theme === 'monochrome') {
    const gray = r * 0.3 + g * 0.5 + b * 0.2;
    r = g = b = gray;
  }

  const targetValues = [
    constrain(r * wallpaperSettings.brightness, 0, 255),
    constrain(g * wallpaperSettings.brightness, 0, 255),
    constrain(b * wallpaperSettings.brightness, 0, 255)
  ];
  const targetKey = targetValues.map(value => round(value * 100)).join(',');

  if (!animatedColorValues || colorTargetKey === '') {
    animatedColorValues = targetValues.slice();
    colorStartValues = targetValues.slice();
    colorTargetValues = targetValues.slice();
    colorTargetKey = targetKey;
    colorTransitionProgress = 1;
  } else if (targetKey !== colorTargetKey) {
    colorStartValues = animatedColorValues.slice();
    colorTargetValues = targetValues.slice();
    colorTargetKey = targetKey;
    colorTransitionProgress = 0;
  }

  colorTransitionProgress = min(
    1,
    colorTransitionProgress + constrain(deltaTime, 0, 50) / 1000 / colorTransitionDuration
  );
  const eased = 1 - pow(1 - colorTransitionProgress, 3);
  animatedColorValues = colorTargetValues.map((targetValue, index) =>
    lerp(colorStartValues[index], targetValue, eased)
  );
  return color(...animatedColorValues);
}

function approachCircular(value, target, period, amount) {
  let delta = ((target - value + period / 2) % period + period) % period - period / 2;
  return (value + delta * amount + period) % period;
}

class Clock {
  constructor() {
    this.mins = Array.from({ length: 60 }, (_, i) => i);
    this.hrs = Array.from({ length: 24 }, (_, i) => i);
    this.secs = Array.from({ length: 60 }, (_, i) => i);
    this.min = minute();
    this.hr = hour();
    this.sec = second();
  }

  display(now) {
    const m = now.getMinutes();
    const h = now.getHours();
    const s = now.getSeconds();
    const response = min(0.45, 0.085 * wallpaperSettings.speed);

    this.min = approachCircular(this.min, m, 60, response);
    this.sec = approachCircular(this.sec, s, 60, response * 2);
    this.hr = approachCircular(this.hr, h, 24, response * 0.66);

    this.drawRing(this.secs, s, this.sec, 540);
    this.drawRing(this.mins, m, this.min, 470);
    this.drawRing(this.hrs, h, this.hr, 400);
  }

  drawRing(values, current, smoothValue, radius) {
    const step = TWO_PI / values.length;
    push();
    rotate(-smoothValue * step - step);
    for (const value of values) {
      rotate(step);
      if (value === current) {
        fill(255, 255 * min(1, wallpaperSettings.brightness));
      } else {
        fill(255, 100 * wallpaperSettings.brightness);
      }
      text(String(value).padStart(2, '0'), radius, 0);
    }
    pop();
  }
}

window.wallpaper = {
  setPointer(x, y) {
    pointerX = Number(x) || 0;
    pointerY = Number(y) || 0;
  },
  setPaused(value) {
    wallpaperPaused = Boolean(value);
    if (wallpaperPaused) noLoop();
    else loop();
  },
  handleInput(event) {
    if (event?.type === 'mousedown') {
      pointerX = Number(event.x) || 0;
      pointerY = Number(event.y) || 0;
      rotateClockToward(pointerX, pointerY);
    }
  },

  setFPS(value) {
    wallpaperSettings.fps = constrain(Number(value) || 30, 1, 60);
    frameRate(wallpaperSettings.fps);
  },

  applySettings(value) {
    wallpaperSettings.fps = constrain(Number(value.fps) || 30, 1, 60);
    wallpaperSettings.speed = constrain(Number(value.speed) || 1, 0.25, 2);
    wallpaperSettings.scale = constrain(Number(value.scale) || 1, 0.65, 1.25);
    wallpaperSettings.brightness = constrain(Number(value.brightness) || 1, 0.5, 1.5);
    wallpaperSettings.theme = String(value.theme || 'aurora');
    frameRate(wallpaperSettings.fps);
  },

  regenerate() {
    nextAngle = radians(random(-20, 20));
    redraw();
  }
};
